// Guided 1

package main

import (
	"bufio"
	"fmt"
	"os"
	"strings"
)

func main() {
	correctOrder := []string{"merah", "kuning", "hijau", "ungu"}

	reader := bufio.NewReader(os.Stdin)
	succes := true

	for i := 1; i <= 5; i++ {
		fmt.Printf("Percobaan %d : ", i)

		input, _ := reader.ReadString('\n')
		input = strings.TrimSpace(input)
		colors := strings.Split(input, " ")

		for j := 0; j < 4; j++ {
			if colors[j] != correctOrder[j] {
				succes = false
				break
			}
		}

		if !succes {
			break
		}
	}

	if succes {
		fmt.Println("BERHASIL: TRUE")
	} else {
		fmt.Println("BERHASIL: FALSE")
	}
}