// Guided 3

package main

import "fmt"

func main() {
	var nam float32
	var nmk string

	fmt.Print("Masukan nilai : ")
	fmt.Scan(&nam)

	if nam > 80 {
		nmk = "A"
	} else if nam > 72.5 {
		nmk = "B"
	} else if nam > 65 {
		nmk = "C"
	} else if nam > 50 {
		nmk = "D"
	} else if nam > 40 {
		nmk = "E"
	} else {
		nmk = "F"
	}
	fmt.Printf("Nilai Indeks untuk Nilai %.2f adalah %s\n : ", nam, nmk)
}