package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
)

func main() {
	reader := bufio.NewReader(os.Stdin)

	var detail_berat int
	var harga_terpisah int

	fmt.Printf("Berat parsel (gram) : ")
	input, _ := reader.ReadString('\n')
	input = strings.TrimSpace(input)

	berat, err := strconv.Atoi(input)

	if err != nil {
		fmt.Println("Berat yang dimasukkan tidak valid")
	}
	detail_berat = berat % 1000

	if detail_berat < 500 {
		harga_terpisah = detail_berat * 15
	} else {
		harga_terpisah = detail_berat * 5
	}

	fmt.Println("Detail berat : ", math.Floor(float64(berat/1000)), " + ", detail_berat)
	fmt.Println("Detail Biaya : ", berat * 10, " + ", harga_terpisah)

	if berat > 10000 {
		fmt.Println("Total Biaya : ", berat * 10)
	} else {
		fmt.Println("Total Biaya : ", (math.Floor(float64(berat/1000))*10000) + float64(harga_terpisah))
	}
}
