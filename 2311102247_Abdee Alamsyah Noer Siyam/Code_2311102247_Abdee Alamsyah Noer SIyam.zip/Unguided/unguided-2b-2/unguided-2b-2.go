package main

import (
	"bufio"
	"fmt"
	"math"
	"os"
	"strconv"
	"strings"
)

func main() {
	reader := bufio.NewReader(os.Stdin)
	var oleng bool 

	for i := 0; i < 4; i++ {
		fmt.Printf("Masukkan berat belanjaan di kedua kantong: ")
		input, _ := reader.ReadString('\n')
		input = strings.TrimSpace(input)

		parts := strings.Split(input, " ")

		if len(parts) != 2 {
			fmt.Println("Inputan yang diberikan tidak sesuai.")
			continue
		}

		nilai1, err1 := strconv.Atoi(parts[0])
		nilai2, err2 := strconv.Atoi(parts[1])

		if err1 != nil || err2 != nil {
			fmt.Println("Angka yang diberikan tidak valid")
			continue
		}

		if nilai1 < 0 || nilai2 < 0 {
			fmt.Println("Berat yang diberikan tidak boleh negatif")
			continue
		}

		selisih := int(math.Abs(float64(nilai1 - nilai2)))

		if selisih >= 9 {
			oleng = true
		} else {
			oleng = false
		}

		fmt.Println("Sepeda motor pak Andi akan oleng : ", oleng)
	}
	fmt.Println("proses selesai")
}
