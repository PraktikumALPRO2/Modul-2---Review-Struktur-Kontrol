package main

import (
    "fmt"
)

func main() {
	var bilangan int
	faktor := []int{}

	fmt.Printf("Bilangan : ")
	fmt.Scanln(&bilangan)

	for i:= 1; i <= bilangan; i++ {
		if bilangan % i == 0 {
            faktor = append(faktor, i)
        }
	}

	fmt.Println("Faktor : ", faktor)
	if len(faktor) == 2 {
		fmt.Println("Prima : TRUE")
	}else {
		fmt.Println("Prima : FALSE")
	}
}