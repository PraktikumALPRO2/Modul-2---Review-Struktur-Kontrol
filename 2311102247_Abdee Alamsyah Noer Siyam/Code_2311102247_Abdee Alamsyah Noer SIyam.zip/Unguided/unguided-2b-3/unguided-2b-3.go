package main

import (
	"bufio"
	"fmt"
	"os"
	"strconv"
	"strings"
)

func main() {
	reader := bufio.NewReader(os.Stdin)
	fmt.Printf("Nilai K : ")

	var divK float64 = 0
	var divK2 float64 = 0
	var total float64
	var k float64

	input, _ := reader.ReadString('\n')
	input  = strings.TrimSpace(input)

	input2, err := strconv.ParseFloat(input, 64)
	
	k = input2

	if err!= nil {
		fmt.Println("Nilai yang diberikan tidak valid")
	}

	k = k * 4 + 2;
	k = k * k;

	divK = 4 * input2 + 1
	divK2 = 4 * input2 + 3

	divK = divK * divK2;

	total = k / divK;

	fmt.Println("Nilai F(K) = ", total)
}