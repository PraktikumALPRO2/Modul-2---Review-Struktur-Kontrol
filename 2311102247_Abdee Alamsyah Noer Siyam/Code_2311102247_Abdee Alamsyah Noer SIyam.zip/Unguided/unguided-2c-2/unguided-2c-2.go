package main

import "fmt"

func main() {
	var nam float64
	var nmk string

	fmt.Print("Nilai Akhir mata kuliah : ")
	fmt.Scanln(&nam)

	if nam >= 0 && nam <= 100 {
		if nam > 80 {
			nmk = "A"
		}else if nam > 72.5 {
			nmk = "AB"
		}else if nam > 65 {
			nmk = "B"
		}else if nam > 57.5 {
			nmk = "BC"
		}else if nam > 50 {
			nmk = "C"
		}else if nam > 40 {
			nmk = "D"
		}else{
			nmk = "E"
		}

		fmt.Println("Nilai Mata Kuliah : ", nmk)
	}else{
		fmt.Println("Nilai yang diberikan bukan termasuk nilai valid.")
	}

}

/*
1. Ketika User memberikan input nam senilai 80.1, sistem menampilkan nilai mata kuliah berupa A, dimana nmk yang ditampilkan sudah sesuai dengan spesifikasi soal. Hal ini menandakan bahwa program dan seluruh kondisi percabangan sudah sesuai

2. Terdapat 3 kesalahan pada baris kode awal yang diberikan. Kesalahan pertama ialah tidak adanya kontrol percabangan untuk mengatasi nilai input yang diberikan di bawah 0 ataupun di atas 100. Kesalahan kedua terletak pada seluruh kontrol percabangan yang memberikan nilai akhir, dimana didalam kontrol percabangan variabel nam di tugaskan ulang untuk mengganti nilai sebelumnya. Seharusnya variabel nmk yang ditugaskan untuk memberi nilai mata kuliah. Kesalahan ketiga terletak ketidak konsistenan penggunaan else if dan else, dimana pada baris kode terbaru, kontrol percabangan sudah konsisten menggunakan if, else if dan else.

3. Pada program tersebut sudah tidak perlu ada yang diperbaiki jika menggunakan	if else if dan else yang konsisten. dimana jika memberikan input 93.5 nilai yang tampil sudah A, 70.6 nilai yang tampil sudah B, dan 49.5 nilai yang tampil sudah D.
*/