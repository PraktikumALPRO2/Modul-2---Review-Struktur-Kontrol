package main

import "fmt"

func main() {
	var K  float64


	fmt.Print("Nilai : ")
	fmt.Scanln(&K)

	atas := ((4*K+2)*(4*K+2))
	bawah := ((4*K+1)*(4*K+3))

	f := atas / bawah

	fmt.Printf("Nilai f(k) = %.10f", f)
//%.10f digunakan untuk membatasi panjang output hasil

}
