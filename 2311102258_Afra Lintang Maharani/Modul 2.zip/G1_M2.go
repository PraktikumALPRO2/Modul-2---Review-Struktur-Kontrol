package main

import "fmt"

func main() {
	nama := "Afra Lintang Maharani"
	fmt.Print(nama)
}
