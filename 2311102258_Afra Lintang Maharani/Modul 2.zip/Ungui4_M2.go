package main

import (
	"fmt"
)

func main() {
	var (
		totalBerat int
		sisaHarga  int
		hargaPerKg = 10000
		totalBiaya int
	)

	fmt.Print("Masukkan berat persel (gram): ")
	fmt.Scanln(&totalBerat)

	kg := totalBerat / 1000
	gram := totalBerat % 1000
	fmt.Printf("Detail berat: %d kg + %d gram\n", kg, gram)

	biayaKg := kg * hargaPerKg

	if gram >= 500 {
		sisaHarga = gram * 5
	} else {
		sisaHarga = gram * 15
	}

	if totalBerat > 10000 && gram <= 1000 {
		sisaHarga = 0
	}
	fmt.Printf("Detail biaya: Rp. %d + Rp. %d\n", biayaKg, sisaHarga)
	totalBiaya = biayaKg + sisaHarga
	fmt.Printf("Total biaya: Rp. %d\n", totalBiaya)
}
