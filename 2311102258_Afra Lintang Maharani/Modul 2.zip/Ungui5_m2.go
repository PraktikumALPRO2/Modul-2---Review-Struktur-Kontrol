package main

import "fmt"

func main() {

	var nilai int
	var faktor []int

	fmt.Print("Bilangan: ")
	fmt.Scanln(&nilai)
	if nilai > 0 {
		for i := 1; i <= nilai; i++ {
			if nilai%i == 0 {
				faktor = append(faktor, i)
				//append input nilai array
			}
		}
		fmt.Print("Faktor: ")
		for j := 0; j < len(faktor); j++ {

			fmt.Print(faktor[j], " ")
		}
		fmt.Print("\n")
		if len(faktor) == 2 {
			//len adalah panjang array

			fmt.Print("Prima: true")
		} else {
			fmt.Print("Prima: false")
		}

	}
}
