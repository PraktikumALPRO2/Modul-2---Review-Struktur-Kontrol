package main

import (
	"fmt"
	"strings"
)

func main() {
	var (
		N     = 10
		bunga string
		Pita  []string
	)
	//fmt.Print("N : ") //input awal yang tidak terpakai
	//fmt.Scanln(&N)    //input awal yang tidak terpakai
	for i := 1; i <= N; i++ {
		fmt.Printf("Bunga %d: ", i)
		fmt.Scanln(&bunga)
		if strings.EqualFold(bunga, "Selesai") {
			break // Equafold digunakan untuk mencocokan antara inputan user dengan selesai tanpa memperhatikan huruf kapital atau tidak
		}
		Pita = append(Pita, bunga) //append berfungsi untuk menginput suatu nilai kedalam array

	}
	temp := strings.Join(Pita, " - ") //digunakan untuk mengggambungkan nilai array/slice kemudian diberikan tambahab “-“
	fmt.Println("Pita : " + temp + " - ")
	fmt.Print("Bunga : ", len(Pita))
}
